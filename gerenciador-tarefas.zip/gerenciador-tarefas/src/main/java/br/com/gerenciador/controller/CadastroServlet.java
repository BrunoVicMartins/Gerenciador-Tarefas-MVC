package br.com.gerenciador.controller;

import br.com.gerenciador.dao.UsuarioDAO;
import br.com.gerenciador.model.Usuario;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/cadastro")
public class CadastroServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String nome = request.getParameter("nome");
        String email = request.getParameter("email");
        String senha = request.getParameter("senha");

        UsuarioDAO usuarioDAO = new UsuarioDAO();

        if (usuarioDAO.emailJaExiste(email)) {
            request.setAttribute("erro", "Este e-mail já está cadastrado.");
            request.getRequestDispatcher("cadastro.jsp").forward(request, response);
            return;
        }

        Usuario novoUsuario = new Usuario();
        novoUsuario.setNome(nome);
        novoUsuario.setEmail(email);
        novoUsuario.setSenha(senha);

        if (usuarioDAO.cadastrarUsuario(novoUsuario)) {
            response.sendRedirect("login.jsp?sucesso=true");
        } else {
            request.setAttribute("erro", "Ocorreu um erro ao realizar o cadastro. Tente novamente.");
            request.getRequestDispatcher("cadastro.jsp").forward(request, response);
        }
    }
}