package br.com.gerenciador.model;

import java.time.LocalDate; // Importante: Usaremos a classe LocalDate para datas

/**
 * Esta classe representa uma Tarefa.
 * Ela é o nosso "Model" para a tabela 'tarefas' do banco de dados.
 */
public class Tarefa {

    // Colunas da tabela 'tarefas'
    private int id;
    private String nome;
    private String descricao;
    private LocalDate prazo;      // Novo campo para o prazo
    private String prioridade;   // Novo campo para a prioridade

    // Campos auxiliares que não vêm da tabela 'tarefas', mas da 'usuario_tarefas'
    private int usuarioTarefaId;
    private String status;


    // Getters e Setters para todos os campos (essencial para o JSP e Servlets)

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public LocalDate getPrazo() {
        return prazo;
    }

    public void setPrazo(LocalDate prazo) {
        this.prazo = prazo;
    }

    public String getPrioridade() {
        return prioridade;
    }

    public void setPrioridade(String prioridade) {
        this.prioridade = prioridade;
    }

    public int getUsuarioTarefaId() {
        return usuarioTarefaId;
    }

    public void setUsuarioTarefaId(int usuarioTarefaId) {
        this.usuarioTarefaId = usuarioTarefaId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}