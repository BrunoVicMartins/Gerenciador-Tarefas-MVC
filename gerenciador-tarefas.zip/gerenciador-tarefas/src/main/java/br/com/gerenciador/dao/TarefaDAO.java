package br.com.gerenciador.dao;

import br.com.gerenciador.model.Tarefa;
import br.com.gerenciador.util.Conexao;

// PASSO 1: ADICIONE ESTAS IMPORTAÇÕES
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TarefaDAO {

    // PASSO 2: SUBSTITUA ESTE MÉTODO
    /**
     * Insere uma nova tarefa no banco de dados, incluindo prazo e prioridade.
     * @param tarefa O objeto Tarefa com todos os dados a serem salvos.
     * @return true se a inserção foi bem-sucedida, false caso contrário.
     */
    public boolean adicionarTarefa(Tarefa tarefa) {
        // A query SQL agora inclui as novas colunas
        String sql = "INSERT INTO tarefas (nome, descricao, prazo, prioridade) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, tarefa.getNome());
            ps.setString(2, tarefa.getDescricao());
            
            // Para datas, precisamos converter de LocalDate (Java 8+) para java.sql.Date
            // Verificamos se o prazo não é nulo antes de converter
            if (tarefa.getPrazo() != null) {
                ps.setDate(3, java.sql.Date.valueOf(tarefa.getPrazo()));
            } else {
                // Se o prazo for nulo, informamos isso ao JDBC
                ps.setNull(3, Types.DATE);
            }
            
            ps.setString(4, tarefa.getPrioridade());
            
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // PASSO 3: SUBSTITUA ESTE MÉTODO
    /**
     * Lista todas as tarefas cadastradas no sistema, incluindo prazo e prioridade.
     * @return Uma lista de objetos Tarefa.
     */
    // Dentro da classe TarefaDAO.java

    public List<Tarefa> listarTodasTarefasAdmin() {

        // ADIÇÃO 1: Imprimir uma mensagem para sabermos que o método foi chamado.
        System.out.println("--- DEBUG: Entrou em listarTodasTarefasAdmin() ---");

        List<Tarefa> tarefas = new ArrayList<>();
        String sql = "SELECT * FROM tarefas ORDER BY prazo ASC, nome ASC"; 

        try (Connection conn = Conexao.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                // ADIÇÃO 2: Imprimir cada tarefa que for encontrada no banco.
                System.out.println("--- DEBUG: Tarefa encontrada no banco: " + rs.getString("nome"));

                Tarefa tarefa = new Tarefa();
                tarefa.setId(rs.getInt("id"));
                tarefa.setNome(rs.getString("nome"));
                // ... (o resto do seu código que preenche o objeto)

                tarefas.add(tarefa);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Se houver um erro, ele será impresso aqui.
        }

        // ADIÇÃO 3: Imprimir o tamanho da lista antes de retorná-la.
        System.out.println("--- DEBUG: Retornando lista com " + tarefas.size() + " tarefas.");

        return tarefas;
    }

    //
    // Mantenha os outros métodos que você já tinha no TarefaDAO aqui embaixo...
    // listarTarefasDisponiveisParaUsuario, listarTarefasDoUsuario, etc.
    //
    public List<Tarefa> listarTarefasDisponiveisParaUsuario(int idUsuario) {
        List<Tarefa> tarefas = new ArrayList<>();
        // Seleciona tarefas que NÃO estão na lista do usuário
        String sql = "SELECT * FROM tarefas WHERE id NOT IN (SELECT id_tarefa FROM usuario_tarefas WHERE id_usuario = ?) ORDER BY nome ASC";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idUsuario);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Tarefa tarefa = new Tarefa();
                tarefa.setId(rs.getInt("id"));
                tarefa.setNome(rs.getString("nome"));
                tarefa.setDescricao(rs.getString("descricao"));
                if (rs.getObject("prazo") != null) {
                    tarefa.setPrazo(rs.getDate("prazo").toLocalDate());
                }
                tarefa.setPrioridade(rs.getString("prioridade"));
                tarefas.add(tarefa);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tarefas;
    }


    public List<Tarefa> listarTarefasDoUsuario(int idUsuario) {
        List<Tarefa> tarefas = new ArrayList<>();
        String sql = "SELECT t.id, t.nome, t.descricao, t.prazo, t.prioridade, ut.id as usuario_tarefa_id, ut.status " +
                     "FROM tarefas t JOIN usuario_tarefas ut ON t.id = ut.id_tarefa " +
                     "WHERE ut.id_usuario = ?";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idUsuario);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Tarefa tarefa = new Tarefa();
                tarefa.setId(rs.getInt("id"));
                tarefa.setNome(rs.getString("nome"));
                tarefa.setDescricao(rs.getString("descricao"));
                if (rs.getObject("prazo") != null) {
                    tarefa.setPrazo(rs.getDate("prazo").toLocalDate());
                }
                tarefa.setPrioridade(rs.getString("prioridade"));
                tarefa.setUsuarioTarefaId(rs.getInt("usuario_tarefa_id"));
                tarefa.setStatus(rs.getString("status"));
                tarefas.add(tarefa);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tarefas;
    }

    public boolean adicionarTarefaParaUsuario(int idUsuario, int idTarefa) {
        String sql = "INSERT INTO usuario_tarefas (id_usuario, id_tarefa, status) VALUES (?, ?, 'pendente')";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idUsuario);
            ps.setInt(2, idTarefa);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean removerTarefaDoUsuario(int idUsuarioTarefa) {
        String sql = "DELETE FROM usuario_tarefas WHERE id = ?";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idUsuarioTarefa);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean marcarTarefaComoConcluida(int idUsuarioTarefa) {
        String sql = "UPDATE usuario_tarefas SET status = 'concluida' WHERE id = ?";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idUsuarioTarefa);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    // Adicione este método dentro da classe TarefaDAO

    public boolean excluirTarefa(int id) {
        String sql = "DELETE FROM tarefas WHERE id = ?";

        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}