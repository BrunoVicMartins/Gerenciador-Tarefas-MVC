package br.com.gerenciador.controller;

import br.com.gerenciador.dao.TarefaDAO;
import br.com.gerenciador.model.Usuario;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/usuario")
public class UsuarioServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String acao = request.getParameter("acao");
        HttpSession session = request.getSession();
        Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

        if (usuarioLogado == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        TarefaDAO tarefaDAO = new TarefaDAO();

        if ("adicionar".equals(acao)) {
            int idTarefa = Integer.parseInt(request.getParameter("idTarefa"));
            tarefaDAO.adicionarTarefaParaUsuario(usuarioLogado.getId(), idTarefa);
        } else if ("remover".equals(acao)) {
            int idUsuarioTarefa = Integer.parseInt(request.getParameter("idUsuarioTarefa"));
            tarefaDAO.removerTarefaDoUsuario(idUsuarioTarefa);
        } else if ("concluir".equals(acao)) {
            int idUsuarioTarefa = Integer.parseInt(request.getParameter("idUsuarioTarefa"));
            tarefaDAO.marcarTarefaComoConcluida(idUsuarioTarefa);
        }
        
        response.sendRedirect("usuario/painel.jsp");
    }
}