package br.com.gerenciador.controller;

import br.com.gerenciador.dao.TarefaDAO;
import br.com.gerenciador.model.Tarefa;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/admin/painel") // A URL que o navegador chama
public class AdminPainelServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("--- DEBUG: AdminPainelServlet.doGet() FOI CHAMADO ---"); // Novo debug
        TarefaDAO tarefaDAO = new TarefaDAO();
        List<Tarefa> listaDeTarefas = tarefaDAO.listarTodasTarefasAdmin();
        
        request.setAttribute("listaDeTarefas", listaDeTarefas);

        // O caminho para o arquivo JSP DEVE começar com uma barra "/"
        RequestDispatcher dispatcher = request.getRequestDispatcher("/admin/painel.jsp");
        dispatcher.forward(request, response);
    }
}