package br.com.gerenciador.controller;

import br.com.gerenciador.dao.UsuarioDAO;
import br.com.gerenciador.model.Usuario;

// Lembre-se que as suas importações podem ser javax.*
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String senha = request.getParameter("senha");

        UsuarioDAO usuarioDAO = new UsuarioDAO();
        Usuario usuario = usuarioDAO.validarLogin(email, senha);

        if (usuario != null) {
            HttpSession session = request.getSession();
            session.setAttribute("usuarioLogado", usuario);

            if ("admin".equals(usuario.getTipo())) {
                // LINHA CORRIGIDA: Redireciona para a URL do servlet
                response.sendRedirect("admin/painel");
            } else {
                response.sendRedirect("usuario/painel.jsp");
            }
        } else {
            request.setAttribute("erro", "E-mail ou senha inválidos.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}