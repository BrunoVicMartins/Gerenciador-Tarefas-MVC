package br.com.gerenciador.dao;

import br.com.gerenciador.model.Usuario;
import br.com.gerenciador.util.Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioDAO {

    /**
     * Valida as credenciais do usuário no banco de dados.
     * @param email O email fornecido pelo usuário.
     * @param senha A senha fornecida pelo usuário.
     * @return Um objeto Usuario se as credenciais forem válidas, ou null caso contrário.
     */
    public Usuario validarLogin(String email, String senha) {
        // Query SQL para selecionar o usuário com o email e senha correspondentes.
        String sql = "SELECT * FROM usuarios WHERE email = ? AND senha = ?";
        Usuario usuario = null;
        
        // A estrutura try-with-resources garante que a conexão e o PreparedStatement sejam fechados.
        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, email);
            ps.setString(2, senha); // IMPORTANTE: Em um projeto real, a senha deve ser "hasheada" e não salva em texto puro.
            
            // Executa a consulta
            ResultSet rs = ps.executeQuery();
            
            // Se encontrou um resultado, preenche o objeto Usuario.
            if (rs.next()) {
                usuario = new Usuario();
                usuario.setId(rs.getInt("id"));
                usuario.setNome(rs.getString("nome"));
                usuario.setEmail(rs.getString("email"));
                usuario.setTipo(rs.getString("tipo")); // "admin" ou "usuario"
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Em um projeto real, trate a exceção de forma mais robusta (ex: logs).
        }
        return usuario;
    }

    /**
     * Insere um novo usuário no banco de dados.
     * @param usuario O objeto Usuario com os dados a serem cadastrados.
     * @return true se o cadastro foi bem-sucedido, false caso contrário.
     */
    public boolean cadastrarUsuario(Usuario usuario) {
        String sql = "INSERT INTO usuarios (nome, email, senha, tipo) VALUES (?, ?, ?, 'usuario')";
        
        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, usuario.getNome());
            ps.setString(2, usuario.getEmail());
            ps.setString(3, usuario.getSenha()); // IMPORTANTE: A senha deve ser "hasheada" aqui também.
            
            // O executeUpdate() retorna o número de linhas afetadas. Se for > 0, a inserção funcionou.
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Verifica se um e-mail já existe na base de dados.
     * @param email O e-mail a ser verificado.
     * @return true se o e-mail já existe, false caso contrário.
     */
    public boolean emailJaExiste(String email) {
        String sql = "SELECT id FROM usuarios WHERE email = ?";
         try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {
             
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            
            // Se rs.next() for verdadeiro, significa que encontrou um registro com aquele e-mail.
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}