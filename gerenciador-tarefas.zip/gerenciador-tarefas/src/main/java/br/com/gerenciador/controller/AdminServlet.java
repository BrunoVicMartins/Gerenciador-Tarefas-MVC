package br.com.gerenciador.controller;

import br.com.gerenciador.dao.TarefaDAO;
import br.com.gerenciador.model.Tarefa;

import java.time.LocalDate;

// Suas importações podem ser javax.*
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/admin")
public class AdminServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

        @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String acao = request.getParameter("acao");
        TarefaDAO tarefaDAO = new TarefaDAO();

        if ("adicionar".equals(acao)) {
            // Lógica para adicionar que já tínhamos
            String nome = request.getParameter("nome");
            String descricao = request.getParameter("descricao");
            String prazoStr = request.getParameter("prazo");
            String prioridade = request.getParameter("prioridade");

            Tarefa tarefa = new Tarefa();
            tarefa.setNome(nome);
            tarefa.setDescricao(descricao);
            tarefa.setPrioridade(prioridade);

            if (prazoStr != null && !prazoStr.isEmpty()) {
                tarefa.setPrazo(LocalDate.parse(prazoStr));
            }

            tarefaDAO.adicionarTarefa(tarefa);

        } else if ("excluir".equals(acao)) {
            // NOVA LÓGICA PARA EXCLUIR
            // Pega o ID da tarefa que veio do formulário do botão
            int id = Integer.parseInt(request.getParameter("id"));

            // Chama o novo método do DAO para excluir
            tarefaDAO.excluirTarefa(id);
        }

        // Após qualquer ação (adicionar OU excluir), redireciona para o painel
        // para que a lista seja recarregada e mostre o estado atual do banco.
        response.sendRedirect("admin/painel");
    }
    
}