package br.com.gerenciador.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
    // Garanta que a PORTA é 3307
    private static final String URL = "jdbc:mysql://localhost:3307/gerenciador_tarefas?useTimezone=true&serverTimezone=UTC";
    
    // Garanta que o USUÁRIO é 'root'
    private static final String USER = "root";
    
    // Garanta que a SENHA está VAZIA (aspas duplas sem nada dentro)
    private static final String PASSWORD = "";

    public static Connection getConexao() {
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException | SQLException e) {
            // Este é o erro que você está vendo
            e.printStackTrace();
            throw new RuntimeException("Erro na conexão com o banco de dados", e);
        }
        return conn;
    }
}